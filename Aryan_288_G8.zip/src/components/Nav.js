import React, { useState } from 'react';
import '../App.css';
import { Link } from 'react-router-dom';
export default function Nav() {
    const [toggle, setToggle] = useState(false);
    return (
        <div>

            <div className='absolute z-40 right-32 sm:flex hidden  sm:justify-end gap-[5rem] py-[3rem] pr-24 sm:items-center cursor-pointer text-white '>

                <ul className='flex gap-[4rem] text-[1.2rem] font-bold'>
                    <li><Link to="/Home">Home</Link></li>
                    <li><Link to="/Menu">Menu</Link></li>
                    <li><Link to="/Story">Our Story</Link></li>
                    <li><Link to="/Contact">Contact Us</Link></li>
                </ul>
                <div className='md:flex hidden items-center relative'>
                    <input type="text" className="rounded-[50px] text-gray-700 font-400 w-48 remove-outline" placeholder='Search...' />
                    <img src="images/search.png" className='absolute right-3 w-7' alt="" />
                </div>
            </div>


            <div className='absolute  z-10 flex justify-between w-[90%] mx-auto md:hidden pb-[2rem] pl-5'>
                <img src="images/italic_food-removebg-preview.png" className='w-[100px] rounded-full'/>
                <button onClick={e => setToggle(!toggle)}>
                    <i className="fa-solid fa-bars z-10" style={{ color: 'white', fontSize: '25px' }} />
                </button>
            </div>

            {toggle && (
                <div className=' sm:hidden flex flex-col items-center gap-[2rem] py-[2rem] sm:items-center cursor-pointer fixed left-0 right-0 bottom-0 top-0  z-30  bg-[#28292d] text-white '>
                    <button onClick={e => setToggle(!toggle)} className='flex self-end pr-8'>
                        <i className="fa-solid fa-bars" style={{ color: 'white', fontSize: '25px' }} />
                    </button>
                    <ul className='flex flex-col gap-5 text-[1.2rem] font-bold self-stretch text-center'>
                        <li className='border-2 border-white w-full py-5 hover:bg-black' onClick={e => setToggle(!toggle)}><Link to="/Home">Home</Link></li>
                        <li className='border-2 border-white w-full py-5 hover:bg-black' onClick={e => setToggle(!toggle)}><Link to="/Menu">Menu</Link></li>
                        <li className='border-2 border-white w-full py-5 hover:bg-black' onClick={e => setToggle(!toggle)}><Link to="/Story">Our Story</Link></li>
                        <li className='border-2 border-white w-full py-5 hover:bg-black' onClick={e => setToggle(!toggle)}><Link to="/Contact">Contact Us</Link></li>
                    </ul>
                    <div className='flex items-center relative self-stretch'>
                        <input type="text" className="rounded-[50px] text-gray-700 font-400 w-full remove-outline" placeholder='Search...' />
                        <img src="images/search.png" className='absolute right-3 w-7' alt="" />
                    </div>
                </div>

            )}
        </div>
    )
}
