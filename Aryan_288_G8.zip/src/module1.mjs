import ui, {b,c,d} from './module.mjs';
console.log(ui);
console.log(b);
console.log(c);
console.log(d);