// import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import Header from './components/Header';
import Nav from './components/Nav';
import { NavbarDefault } from './components/Nav';
import { Route, Routes } from 'react-router-dom';
import Menu from './components/Menu';
import Story from './components/Story';
import Contact from './components/Contact';
function App() {
  return (

    <>
      <div className='App'>
        {/* <Home /> */}
        <Nav/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/Home' element={<Home/>}/>
          <Route path='/Menu' element={<Menu/>}/>
          <Route path='/Story' element={<Story/>}/>
          <Route path='/Contact' element={<Contact/>}/>
        </Routes>
      </div>
      
    </>
  );
}

export default App;
