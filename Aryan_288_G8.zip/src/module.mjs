const a="Aryan";
const b="Bairagi";
const c="Shukla";
const d="Daksh";

export default a;
export {c};
export {b};
export {d};